package com.example.todolistapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays; // Ekledim

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "ToDoList.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_TASKS = "tasks";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_TIME = "time";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TASKS_TABLE = "CREATE TABLE " + TABLE_TASKS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TITLE + " TEXT,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_DATE + " TEXT,"
                + COLUMN_TIME + " TEXT"
                + ")";
        db.execSQL(CREATE_TASKS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        onCreate(db);
    }

    public long addTask(Task task) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, task.getTitle());
        values.put(COLUMN_DESCRIPTION, task.getDescription());
        values.put(COLUMN_DATE, task.getDate());
        values.put(COLUMN_TIME, task.getTime());
        long id = db.insert(TABLE_TASKS, null, values);
        db.close();
        return id;
    }

    public List<Task> getAllTasks() {
        List<Task> taskList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_TASKS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        int columnIndexId = cursor.getColumnIndex(COLUMN_ID);
        int columnIndexTitle = cursor.getColumnIndex(COLUMN_TITLE);
        int columnIndexDescription = cursor.getColumnIndex(COLUMN_DESCRIPTION);
        int columnIndexDate = cursor.getColumnIndex(COLUMN_DATE);
        int columnIndexTime = cursor.getColumnIndex(COLUMN_TIME);

        while (cursor.moveToNext()) {
            Task task = new Task();


            if (columnIndexId != -1) {
                task.setId(cursor.getInt(columnIndexId));
            }

            if (columnIndexTitle != -1) {
                task.setTitle(cursor.getString(columnIndexTitle));
            }

            if (columnIndexDescription != -1) {
                task.setDescription(cursor.getString(columnIndexDescription));
            }

            if (columnIndexDate != -1) {
                task.setDate(cursor.getString(columnIndexDate));
            }

            if (columnIndexTime != -1) {
                task.setTime(cursor.getString(columnIndexTime));
            }

            taskList.add(task);
        }

        cursor.close();
        db.close();
        return taskList;
    }
    public Task getTaskById(int taskId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_TASKS,
                new String[]{COLUMN_ID, COLUMN_TITLE, COLUMN_DESCRIPTION, COLUMN_DATE, COLUMN_TIME},
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(taskId)},
                null,
                null,
                null,
                null
        );

        Task task = null;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                task = new Task();
                int idIndex = cursor.getColumnIndex(COLUMN_ID);
                int titleIndex = cursor.getColumnIndex(COLUMN_TITLE);
                int descriptionIndex = cursor.getColumnIndex(COLUMN_DESCRIPTION);
                int dateIndex = cursor.getColumnIndex(COLUMN_DATE);
                int timeIndex = cursor.getColumnIndex(COLUMN_TIME);

                if (idIndex != -1) {
                    task.setId(cursor.getInt(idIndex));
                }

                if (titleIndex != -1) {
                    task.setTitle(cursor.getString(titleIndex));
                }

                if (descriptionIndex != -1) {
                    task.setDescription(cursor.getString(descriptionIndex));
                }

                if (dateIndex != -1) {
                    task.setDate(cursor.getString(dateIndex));
                }

                if (timeIndex != -1) {
                    task.setTime(cursor.getString(timeIndex));
                }
            }

            cursor.close();
        }

        db.close();
        return task;
    }
    public void updateTask(Task task) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, task.getTitle());
        values.put(COLUMN_DESCRIPTION, task.getDescription());
        values.put(COLUMN_DATE, task.getDate());
        values.put(COLUMN_TIME, task.getTime());
        db.update(TABLE_TASKS, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(task.getId())});
        db.close();
    }

    public void deleteTask(int taskId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_TASKS, COLUMN_ID + " = ?",
                new String[]{String.valueOf(taskId)});
        db.close();
    }
    public List<Task> getTasksByDate(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Task> taskList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_TASKS +
                " WHERE " + COLUMN_DATE + " = ?";

        Cursor cursor = db.rawQuery(selectQuery, new String[]{date});


        String[] columnNames = cursor.getColumnNames();

        Set<String> columnSet = new HashSet<>(Arrays.asList(columnNames));

        int columnIndexId = -1;
        int columnIndexTitle = -1;
        int columnIndexDescription = -1;
        int columnIndexDate = -1;
        int columnIndexTime = -1;

        if (columnSet.contains(COLUMN_ID)) {
            columnIndexId = cursor.getColumnIndex(COLUMN_ID);
        }

        if (columnSet.contains(COLUMN_TITLE)) {
            columnIndexTitle = cursor.getColumnIndex(COLUMN_TITLE);
        }

        if (columnSet.contains(COLUMN_DESCRIPTION)) {
            columnIndexDescription = cursor.getColumnIndex(COLUMN_DESCRIPTION);
        }

        if (columnSet.contains(COLUMN_DATE)) {
            columnIndexDate = cursor.getColumnIndex(COLUMN_DATE);
        }

        if (columnSet.contains(COLUMN_TIME)) {
            columnIndexTime = cursor.getColumnIndex(COLUMN_TIME);
        }

        if (cursor.moveToFirst()) {
            do {
                Task task = new Task();


                if (columnIndexId != -1) {
                    task.setId(cursor.getInt(columnIndexId));
                }

                if (columnIndexTitle != -1) {
                    task.setTitle(cursor.getString(columnIndexTitle));
                }

                if (columnIndexDescription != -1) {
                    task.setDescription(cursor.getString(columnIndexDescription));
                }

                if (columnIndexDate != -1) {
                    task.setDate(cursor.getString(columnIndexDate));
                }

                if (columnIndexTime != -1) {
                    task.setTime(cursor.getString(columnIndexTime));
                }

                taskList.add(task);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return taskList;
    }



}


