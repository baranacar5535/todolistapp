package com.example.todolistapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;

public class EditTaskActivity extends AppCompatActivity {
    private EditText editTitleEditText, editDescriptionEditText;
    private Button saveButton;
    private DatabaseHelper databaseHelper;
    private int taskId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_task);

        editTitleEditText = findViewById(R.id.editTitleEditText);
        editDescriptionEditText = findViewById(R.id.editDescriptionEditText);
        saveButton = findViewById(R.id.saveButton);

        databaseHelper = new DatabaseHelper(this);


        taskId = getIntent().getIntExtra("TASK_ID", -1);


        loadTaskDetails();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateTask();
            }
        });
    }

    private void loadTaskDetails() {

        Task task = databaseHelper.getTaskById(taskId);


        if (task != null) {
            editTitleEditText.setText(task.getTitle());
            editDescriptionEditText.setText(task.getDescription());
        }
    }

    private void updateTask() {

        String updatedTitle = editTitleEditText.getText().toString();
        String updatedDescription = editDescriptionEditText.getText().toString();


        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());
        String currentTime = timeFormat.format(new Date());


        Task updatedTask = new Task();
        updatedTask.setId(taskId);
        updatedTask.setTitle(updatedTitle);
        updatedTask.setDescription(updatedDescription);
        updatedTask.setDate(currentDate);
        updatedTask.setTime(currentTime);


        Log.d("EditTaskActivity", "Updating task with ID: " + taskId);
        Log.d("EditTaskActivity", "Updated Title: " + updatedTitle);
        Log.d("EditTaskActivity", "Updated Description: " + updatedDescription);


        databaseHelper.updateTask(updatedTask);


        Log.d("EditTaskActivity", "Task updated successfully");


        Intent resultIntent = new Intent();
        resultIntent.putExtra("UPDATED_TASK", updatedTask);
        setResult(RESULT_OK, resultIntent);


        finish();
    }



}
