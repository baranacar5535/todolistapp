package com.example.todolistapp;
import android.content.Intent;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;
import java.util.Calendar;
import android.app.DatePickerDialog;
import android.widget.DatePicker;
import java.util.GregorianCalendar;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    private EditText titleEditText, descriptionEditText;
    private Button addButton;
    private ListView taskListView;
    private DatabaseHelper databaseHelper;
    private List<Task> taskList;
    private TaskAdapter taskAdapter;
    private Button filterByDateButton;
    private Calendar selectedDate;
    private static final int EDIT_TASK_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titleEditText = findViewById(R.id.titleEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        addButton = findViewById(R.id.addButton);
        taskListView = findViewById(R.id.taskListView);

        databaseHelper = new DatabaseHelper(this);
        taskList = databaseHelper.getAllTasks();

        taskAdapter = new TaskAdapter(this, taskList);
        taskListView.setAdapter(taskAdapter);

        Button showAllButton = findViewById(R.id.showAllButton);
        showAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showAllTasks();
            }
        });

        filterByDateButton= findViewById(R.id.filterByDateButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTask();
            }
        });

        taskListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                showTaskOptionsDialog(position);
            }
        });
        filterByDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });
    }

    private void showTaskOptionsDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Task Options")
                .setItems(new CharSequence[]{"Edit", "Delete"}, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                // Edit task
                                editTask(position);
                                break;
                            case 1:
                                // Delete task
                                deleteTask(position);
                                break;
                        }
                    }
                });
        builder.create().show();
    }
    private void editTask(final int position) {

        int taskId = taskList.get(position).getId();


        Intent intent = new Intent(MainActivity.this, EditTaskActivity.class);
        intent.putExtra("TASK_ID", taskId);
        startActivityForResult(intent, EDIT_TASK_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == EDIT_TASK_REQUEST_CODE && resultCode == RESULT_OK) {

            Task updatedTask = (Task) data.getSerializableExtra("UPDATED_TASK");


            int position = findTaskPositionById(updatedTask.getId());
            if (position != -1) {
                taskList.set(position, updatedTask);
                taskAdapter.notifyDataSetChanged();
            }
        }
    }



    private int findTaskPositionById(int taskId) {
        for (int i = 0; i < taskList.size(); i++) {
            if (taskList.get(i).getId() == taskId) {
                return i;
            }
        }
        return -1;
    }


    private void deleteTask(final int position) {
        Task taskToDelete = taskList.get(position);


        databaseHelper.deleteTask(taskToDelete.getId());


        taskList.remove(position);


        taskAdapter.notifyDataSetChanged();
    }
    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                        selectedDate = new GregorianCalendar(year, month, dayOfMonth);
                        getTasksByDate(selectedDate.getTime());
                    }
                },
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }
    private void getTasksByDate(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String formattedDate = dateFormat.format(date);

        List<Task> filteredTasks = databaseHelper.getTasksByDate(formattedDate);

        if (filteredTasks.isEmpty()) {

            Toast.makeText(this, "There is nothing to do on this day!", Toast.LENGTH_SHORT).show();
        } else {

            taskList.clear();
            taskList.addAll(filteredTasks);
            taskAdapter.notifyDataSetChanged();
        }
    }



    private void addTask() {
        String title = titleEditText.getText().toString();
        String description = descriptionEditText.getText().toString();


        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());
        String currentTime = timeFormat.format(new Date());


        if (!title.isEmpty()) {
            Task task = new Task();
            task.setTitle(title);
            task.setDescription(description);
            task.setDate(currentDate);
            task.setTime(currentTime);

            long id = databaseHelper.addTask(task);
            if (id != -1) {
                task.setId((int) id);
                taskList.add(task);
                taskAdapter.notifyDataSetChanged();
                clearInputFields();
            } else {

            }
        } else {

        }
    }

    private void clearInputFields() {
        titleEditText.getText().clear();
        descriptionEditText.getText().clear();
    }
    private void showAllTasks() {

        taskList.clear();
        taskList.addAll(databaseHelper.getAllTasks());
        taskAdapter.notifyDataSetChanged();
    }


}
